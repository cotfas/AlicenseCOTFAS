Box icon was designed by S.Shek.

By downloading and using this icons, you agree to the following terms

- You may NOT resell this icons
- You may use this icons for personal
- You may translate or distribute


http://www.sshek.com
Email:oooshek@gmail.com
